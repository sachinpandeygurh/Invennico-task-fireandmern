import TableComponent from "../components/Table";

const Home = () => {
  

  return (
    <>
      <div className="container">
        <div className="">
          <div className="col-md-12 m-auto">
           <TableComponent/>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;